import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

class Player1 extends StatefulWidget {
  @override
  _Player1State createState() => _Player1State();
}

class _Player1State extends State<Player1> {
  final player = AudioPlayer();
  ConcatenatingAudioSource playlist = ConcatenatingAudioSource(
    // Start loading next item just before reaching it
    useLazyPreparation: true,
    // Customise the shuffle algorithm
    shuffleOrder: DefaultShuffleOrder(), children: [],
  );

  int currentIndex = 0;

  final audioTitles = [
    'Track 1',
    'Track 2',
    // Add titles for more audio files
  ];

  @override
  void initState() {
    super.initState();
    initPlaylist();
  }

  Future<void> initPlaylist() async {
    for (final audioFile in playlistFiles) {
      await playlist.add(AudioSource.asset(audioFile));
    }

    await player.setAudioSource(playlist, preload: true);
    player.sequenceStateStream.listen((sequenceState) {
      if (sequenceState?.currentIndex != currentIndex) {
        currentIndex = sequenceState!.currentIndex;
      }
    });
  }

  void playNext() {
    if (currentIndex < playlistFiles.length - 1) {
      currentIndex++;
      player.seek(Duration.zero, index: currentIndex);
    }
  }

  void playPrevious() {
    if (currentIndex > 0) {
      currentIndex--;
      player.seek(Duration.zero, index: currentIndex);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Audio Player'),
      ),
      body: Column(
        children: [
          ListTile(
            title: StreamBuilder<SequenceState?>(
              stream: player.sequenceStateStream,
              builder: (context, snapshot) {
                final sequenceState = snapshot.data;
                if (sequenceState != null) {
                  final item = sequenceState.currentSource;
                  if (item is AudioSource) {
                    return Column(
                      children: [
                        if (item?.tag != null && item?.tag != '')
                          Image.asset(item?.tag),
                        Text('Now Playing: ${audioTitles[currentIndex]}'),
                      ],
                    );
                  }
                }
                return Text('Now Playing: N/A');
              },
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              IconButton(
                icon: Icon(Icons.skip_previous),
                onPressed: playPrevious,
              ),
              IconButton(
                icon: StreamBuilder<PlayerState>(
                  stream: player.playerStateStream,
                  builder: (context, snapshot) {
                    if (snapshot.data?.processingState ==
                        ProcessingState.buffering) {
                      return CircularProgressIndicator();
                    } else if (player.playing) {
                      return Icon(Icons.pause);
                    } else {
                      return Icon(Icons.play_arrow);
                    }
                  },
                ),
                onPressed: () {
                  if (player.playing) {
                    player.pause();
                  } else {
                    player.play();
                  }
                },
              ),
              IconButton(
                icon: Icon(Icons.skip_next),
                onPressed: playNext,
              ),
            ],
          ),
          Expanded(
            child: ListView.builder(
              itemCount: audioTitles.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(audioTitles[index]),
                  onTap: () {
                    currentIndex = index;
                    player.seek(Duration.zero, index: currentIndex);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }
}

final playlistFiles = [
  'assets/audios/s1.mp3',
  'assets/audios/s2.mp3',
  'assets/audios/s3.mp3'
  // Add more audio files to the playlist
];
