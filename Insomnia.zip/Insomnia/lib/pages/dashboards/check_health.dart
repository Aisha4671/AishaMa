import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CheckHealth extends StatefulWidget {
  const CheckHealth({super.key});

  @override
  State<CheckHealth> createState() => _CheckHealthState();
}

class _CheckHealthState extends State<CheckHealth> {
  Future<void> _showWidgets() async {
    await Future.delayed(Duration(seconds: 5));
    setState(() {
      _widgetToShow = Column(
        children: [
          CircularProgressIndicator(),
          Text(
            'Please Wait...',
            style: TextStyle(color: Colors.white),
          ),
        ],
      );
    });
    await Future.delayed(Duration(seconds: 5));
    setState(() {
      _widgetToShow = const Column(
        children: [
          CircularProgressIndicator(
            color: Colors.green,
          ),
          Text(
            'Initializing ',
            style: TextStyle(color: Colors.white),
          )
        ],
      );
    });
    await Future.delayed(Duration(seconds: 5));
    setState(() {
      _widgetToShow = const Column(
        children: [
          CircularProgressIndicator(
            color: Colors.blue,
          ),
          Text(
            'Connecting Body Sensor...',
            style: TextStyle(color: Colors.white),
          )
        ],
      );
    });
    await Future.delayed(Duration(seconds: 5));
    setState(() {
      _widgetToShow = const Column(
        children: [
          CircularProgressIndicator(
            color: Colors.blue,
          ),
          Text(
            'Connecting to Fit Device,',
            style: TextStyle(color: Colors.white),
          )
        ],
      );
    });
    setState(() {
      _widgetToShow = const Column(
        children: [
          CircularProgressIndicator(
            color: Colors.blue,
          ),
          Text(
            'Finalizing...',
            style: TextStyle(color: Colors.white),
          )
        ],
      );
    });
    setState(() {
      _widgetToShow = const Column(
        children: [
          CircularProgressIndicator(
            color: Colors.blue,
          ),
          Text(
            ' compiling Result',
            style: TextStyle(color: Colors.white),
          )
        ],
      );
    });

    await Future.delayed(Duration(seconds: 10));
    setState(() {
      _widgetToShow = SizedBox(
        width: 250.0,
        child: DefaultTextStyle(
          style: const TextStyle(
            fontSize: 25.0,
            fontFamily: 'Agne',
          ),
          child: AnimatedTextKit(
            // pause: Duration(seconds: 10),
            animatedTexts: [
              TypewriterAnimatedText('>>>>>>>>>>>>>>>>>>>>'),
              TypewriterAnimatedText('Measuring Health....'),
              TypewriterAnimatedText(
                  speed: Duration(microseconds: 500), '..................'),
              TypewriterAnimatedText('Error No Fit Device Found'),
            ],
            onTap: () {
              print("Tap Event");
            },
          ),
        ),
      );
    });

    await Future.delayed(Duration(seconds: 20));
    setState(() {
      _widgetToShow = Text(
        "No Fit Device Found",
        style: TextStyle(color: Colors.pink, fontWeight: FontWeight.bold),
      );
    });
  }

  Widget _widgetToShow = Center();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chech health'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Center(
              child: Container(
                width: 300,
                height: 200,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Center(child: _widgetToShow),
                ),
                color: Colors.black,
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _showWidgets,
              child: Text("Check health"),
            ),
          ],
        ),
      ),
    );
  }
}
