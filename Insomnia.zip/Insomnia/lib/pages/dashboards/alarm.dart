import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Alarm extends StatefulWidget {
  @override
  _AlarmState createState() => _AlarmState();
}

class _AlarmState extends State<Alarm> {
  List<Medicine> medicines = [];

  @override
  void initState() {
    super.initState();
    loadMedicines();
  }

  void loadMedicines() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      medicines = (prefs.getStringList('medicines') ?? [])
          .map((medJson) => Medicine.fromJson(medJson))
          .toList();
    });
  }

  void saveMedicines() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setStringList(
        'medicines', medicines.map((med) => med.toJson()).toList());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Medicine Reminder'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              children: medicines
                  .map((med) => Card(
                        child: ListTile(
                          title: Text(med.name),
                          subtitle: Row(
                            children: [
                              Text(med.time.toString()),
                              SizedBox(),
                              Text(" Dosage "),
                              SizedBox(),
                              Text(
                                med.dosage.toString(),
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                          trailing: IconButton(
                            icon: Icon(Icons.delete),
                            onPressed: () {
                              setState(() {
                                medicines.remove(med);
                                saveMedicines();
                              });
                            },
                          ),
                        ),
                      ))
                  .toList(),
            ),
          ),
          AddMedicineCard(
            onSubmit: (name, dosage, time, repeat, vibrate, sound) {
              final medicine = Medicine(
                name: name,
                dosage: dosage,
                time: time,
                repeating: repeat,
                vibrate: vibrate,
                sound: sound,
              );
              setState(() {
                medicines.add(medicine);
                saveMedicines();
              });
            },
          ),
        ],
      ),
    );
  }
}

class AddMedicineCard extends StatefulWidget {
  final Function(String name, int dosage, TimeOfDay time, bool repeat,
      bool vibrate, String? sound) onSubmit;

  AddMedicineCard({required this.onSubmit});

  @override
  _AddMedicineCardState createState() => _AddMedicineCardState();
}

class _AddMedicineCardState extends State<AddMedicineCard> {
  final formKey = GlobalKey<FormState>();
  String name = '';
  int dosage = 0;
  TimeOfDay time = TimeOfDay.now();
  bool repeating = false;
  bool vibrate = true;
  String? sound;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: formKey,
          child: Column(
            children: [
              TextFormField(
                decoration: InputDecoration(labelText: 'Name'),
                validator: (val) => val!.isEmpty ? 'Name required' : null,
                onSaved: (val) => name = val!,
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Dosage'),
                keyboardType: TextInputType.number,
                validator: (val) => val!.isEmpty ? 'Dosage required' : null,
                onSaved: (val) => dosage = int.parse(val!),
              ),
              ElevatedButton(
                onPressed: pickTime,
                child: Text('Select time'),
              ),
              SwitchListTile(
                title: Text('Repeat'),
                value: repeating,
                onChanged: (val) {
                  setState(() {
                    repeating = val;
                  });
                },
              ),
              CheckboxListTile(
                title: Text('Vibrate'),
                value: vibrate,
                onChanged: (val) {
                  setState(() {
                    vibrate = val!;
                  });
                },
              ),
              DropdownButton(
                hint: Text('Select sound'),
                value: sound,
                items: [
                  DropdownMenuItem(
                    child: Text('Default'),
                    value: null,
                  ),
                  DropdownMenuItem(
                    child: Text('Custom'),
                    value: 'assets/audio/s1.mp3',
                  ),
                ],
                onChanged: (val) {
                  setState(() {
                    sound = val;
                  });
                },
              ),
              ElevatedButton(
                onPressed: submit,
                child: Text('Save'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void pickTime() async {
    final time = await showTimePicker(
      context: context,
      initialTime: this.time,
    );
    if (time != null) {
      setState(() {
        this.time = time;
      });
    }
  }

  void submit() {
    final form = formKey.currentState!;
    if (form.validate()) {
      form.save();
      widget.onSubmit(
        name,
        dosage,
        time,
        repeating,
        vibrate,
        sound,
      );
      form.reset();
    }
  }
}

class Medicine {
  final String name;
  final int dosage;
  final TimeOfDay time;
  final bool repeating;
  final bool vibrate;
  final String? sound;

  Medicine({
    required this.name,
    required this.dosage,
    required this.time,
    required this.repeating,
    required this.vibrate,
    this.sound,
  });

  factory Medicine.fromJson(String json) {
    final parts = json.split('|');
    return Medicine(
      name: parts[0],
      dosage: int.parse(parts[1]),
      time: TimeOfDay(hour: int.parse(parts[2]), minute: int.parse(parts[3])),
      repeating: parts[4] == '1',
      vibrate: parts[5] == '1',
      sound: parts[6],
    );
  }

  String toJson() {
    return '$name|$dosage|${time.hour}|${time.minute}|${repeating ? 1 : 0}|${vibrate ? 1 : 0}|$sound';
  }
}
