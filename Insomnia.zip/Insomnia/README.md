# insomnia

Insomnia final year project.

## Getting Started



# project Requirements
1- windows 10 or later
2- Android Studio v 2022 or later
3- latest android SDK
4- android api level 32, min21
5- Platform android-34, build-tools 33.0.2
6- latest jdk
7- latest Dart SDK
8- flutter framework



