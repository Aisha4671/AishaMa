package com.example.insomnia

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
