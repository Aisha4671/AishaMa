import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class Insomnia extends StatefulWidget {
  @override
  State<Insomnia> createState() => _InsomniaState();
}

class _InsomniaState extends State<Insomnia> {
  late VideoPlayerController _controller;

  @override
  void initState() {
    String link = "assets/videos/ins1.mp4";
    super.initState();
    _controller = VideoPlayerController.asset(link,
        videoPlayerOptions: VideoPlayerOptions(allowBackgroundPlayback: true))
      ..initialize().then((_) {
        // Ensure the first frame is shown after the video is initialized, even before the play button has been pressed.
        setState(() {
          _controller.play();
        });
      });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Insomnia'),
      ),
      body: ListView(
        children: <Widget>[
          // Title Section
          Container(
            padding: EdgeInsets.all(20),
            child: Text(
              'Understanding Insomnia',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
          ),

          // Image Section
          Card(
            margin: EdgeInsets.all(10),
            child: Image.asset('assets/images/ins2.png'),
          ),

          // Text Section
          Card(
            margin: EdgeInsets.all(10),
            child: Padding(
              padding: EdgeInsets.all(10),
              child: Text(
                'Insomnia is a common sleep disorder characterized by difficulty falling asleep or staying asleep. It can have various causes and can impact your daily life...',
                style: TextStyle(fontSize: 18),
              ),
            ),
          ),

          // Video Section
          Card(
            margin: EdgeInsets.all(10),
            child: AspectRatio(
              aspectRatio: 16 / 9, // You can adjust this ratio as needed
              child: _controller.value.isInitialized
                  ? AspectRatio(
                      aspectRatio: _controller.value.aspectRatio,
                      child: VideoPlayer(_controller),
                    )
                  : Container(),
            ), // Create a VideoPlayerWidget to display the video
          ),
          Card(
            margin: EdgeInsets.all(10),
            child: Padding(
              padding: EdgeInsets.all(10),
              child: Text(
                'Most cases of insomnia are related to poor sleeping habits, depression, anxiety, lack of exercise, chronic illness or certain medication.'
                ' Symptoms may include difficulty falling or staying asleep and not feeling well-rested.',
                style: TextStyle(fontSize: 18),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
